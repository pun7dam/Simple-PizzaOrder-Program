

class Pizza:
    size = "";  
    price = 0.0;
    listToping = [];
    def __init__(self):
        '''
        Constructor
        '''                
    
    
