

from Shop import Shop

shop = Shop(); # calling shop: and program starts up.
#shop.__init__();

