package pizzaassignment;

public class PizzaAssignment {

    public static void main(String[] args)
    {
        Shop s = new Shop();   // running of pizza application. Object creation      
    }

}
