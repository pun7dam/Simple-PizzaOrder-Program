package pizzaassignment;

import java.util.ArrayList;

public class Order
{
    // Declaration of class variables
    String name;
    int phone;
    String address;
    ArrayList<Pizza> listOrder = new ArrayList(); // Array list of pizza

    /* Below: get and set method names */
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getPhone()
    {
        return phone;
    }

    public void setPhone(int phone)
    {
        this.phone = phone;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public ArrayList<Pizza> getListOrder()
    {
        return listOrder;
    }

    public void setListOrder(ArrayList<Pizza> listOrder)
    {
        this.listOrder = listOrder;
    }   

    
}
