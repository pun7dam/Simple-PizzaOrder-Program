package pizzaassignment;

import java.util.Scanner;

public class Topping
{

    final String[] ListTopping =
    {
        "Bacon", "Olives", "Ham", "Mushrooms", "Pineapple", "Salami", "Anchovies"
    };
    final int MAXTOPPING = 4;
    Pizza pizza;
    Scanner in;

    public Topping()
    {
        in = new Scanner(System.in);
    }

    public void initLoad(Pizza p)  // Load all the methods
    {
        this.pizza = p;
        headerInfo();
        addTopping();
    }
    
    // List of topping option available for pizza
    public void headerInfo()
    {
        System.out.println("|----------------------------------------|");
        System.out.println("|\t Topping available are \t\t|");
        System.out.println("|----------------------------------------|");
        int id = 1;
        for (String s : ListTopping)
        {
            System.out.println("| " + id + ": " + s + "\t\t\t\t|\n");
            id++;
        }
        System.out.println("|----------------------------------------|\n");
        System.out.println("| 0 for returning to order section \t\t\t|\n");
        System.out.println("|----------------------------------------|\n");
    }

    public void addTopping()
    {
        String toppingNo = "-1";
        int countOrderTopping = 0;
        System.out.println("Select the topping types");
        do
        {
            System.out.print("Topping type No.: ");
            // Taking input operation from the console.
            toppingNo = in.nextLine();
            switch(toppingNo)
            {
                case "0":
                    toppingNo= "0";
                    break;
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                    if (countOrderTopping > MAXTOPPING)
                    {
                        System.out.println("\n Maximum topping reached i.e " + countOrderTopping);
                        System.out.println("\n Type zero '0' for return: ");
                        toppingNo = in.nextLine();
                        if (toppingNo.equals("0"))
                        {
                            break;
                        }
                        break;
                    } else if (Integer.parseInt(toppingNo) > ListTopping.length)
                    {
                        System.out.println("Topping order not found.Try again!.\n");
                    } else
                    {
                        pizza.getListToping().add(ListTopping[Integer.parseInt(toppingNo) - 1]);
                        System.out.println(ListTopping[Integer.parseInt(toppingNo) - 1] + " has been added.\n");
                        countOrderTopping++;
                    }
                    break;
                default:
                    System.out.println("Invalid topping type Id. Check Id.\n");
                    break;                    
            }
        } while (!"0".equals(toppingNo));
    }

}
