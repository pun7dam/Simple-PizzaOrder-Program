package pizzaassignment;

import java.util.ArrayList;

enum Size
{

    SMALL, MEDIUM, LARGE
}

public class Pizza
{
    // Declaration of class variables
    private Enum size;
    private double price=0;
    private ArrayList<String> listToping = new ArrayList<>(); // Array list of string type

    public Pizza()  {    }

    public Enum getSize()
    {
        return size;
    }

    public void setPrice(double price)
    {
        this.price = price;
    }

    public double getPrice()
    {
        return price;
    }

    public void setSize(Enum size)
    {
        this.size = size;
    }

    public ArrayList<String> getListToping()
    {
        return listToping;
    }

    public void setLstToping(ArrayList<String> lstToping)
    {
        this.listToping = lstToping;
    }

}
