package pizzaassignment;
import java.util.Scanner;

enum Shipment
{

    CARDORDER, COLLECT, DELIVERY
}

public final class Shop
{
    //Declaration of class variables
    Pizza pizza = null;
    Order order = new Order();
    Topping t = new Topping();
    float priceEachTopping = 1;
    float deliveryCharge = 8;
    Scanner in;

    public Shop()
    {
        in = new Scanner(System.in);
        headerInfo();
        PizzaSetup();
    }

    public void PizzaSetup()
    {
        String operationInput="";
        do
        {
            // Display menu.
            System.out.print("Order Size: ");
            // Taking input operation from the console.            
            operationInput = in.nextLine();
            switch (operationInput)
            {
                case "0":
                    System.out.println("Thank you for visiting Pizza shop");
                    System.exit(0);
                    break;
                case "1": // Small Pizza Size  
                    pizza = new Pizza();  // Everytime new Pizza object creation
                    pizza.setSize(Size.SMALL);
                    pizza.setPrice(5.0);
                    t.initLoad(pizza);
                    order.getListOrder().add(pizza); // adding topping order
                    headerInfo();
                    break;
                case "2":  // Medium Pizza Size1
                    pizza = new Pizza();
                    pizza.setSize(Size.MEDIUM);
                    pizza.setPrice(8.0);
                    t.initLoad(pizza);
                    order.getListOrder().add(pizza); // adding topping order
                    headerInfo();
                    break;
                case "3":  // Large Pizza Size
                    pizza = new Pizza();
                    pizza.setSize(Size.LARGE);
                    pizza.setPrice(12.0);
                    t.initLoad(pizza);
                    order.getListOrder().add(pizza); // adding topping order
                    headerInfo();
                    break;
                case "4": // Display of order information in cart.                      
                    orderCart(Shipment.CARDORDER);
                    break;
                case "5": // Display of order summary
                    shipmentSummary();
                    break;
                case "6": // Removing items from the cart.
                    clearOrderCart("CLEAR");
                    break;
                default:
                    System.out.println("Invalid Order operation Id");
                    break;
            }
        } while (operationInput != "0");

    }

    public void clearOrderCart(String msg)
    {
        if (order.listOrder.size() > 0)
        {
            pizza = new Pizza();
            order = new Order();
            if(msg =="CLEAR")
                System.out.println("Removed Pizza items in the Order cart.\n");
        } else
        {
            System.out.println("Order cart is already empy.");
        }
    }

    // List of menu option for the user.
    public void headerInfo()
    {  
        System.out.println("|-----------------------------------------------|");
        System.out.println("|\t Pizza Shop \t\t|");
        System.out.println("|-----------------------------------------------|");
        System.out.println("|Press 0, 1, 2, 3, 4, 5 and 6 for the operations|");
        System.out.println("|-----------------------------------------------|");
        System.out.println("| 0: Exit \t\t\t\t\t|");
        System.out.println("| 1: For Small Pizza  \t\t\t\t|");
        System.out.println("| 2: For Medium Pizza \t\t\t\t|");
        System.out.println("| 3: For Large  Pizza \t\t\t\t|");
        System.out.println("| 4: View Order Cart \t\t\t|\t");
        System.out.println("| 5: For Order Shipment \t\t\t|");
        System.out.println("| 6: Clear Order Cart \t\t\t|\t");
        System.out.println("|-----------------------------------------------|\n");
    }

    // display of information present in the order i.e array list of pizza ordered
    public void orderCart(Shipment method)
    {   
        double total = 0.0;
        System.out.println("|---------------------------------------------------------------|");
        System.out.println("|\t\t PIZZA ITEMS \t\t\t\t\t|");

        if (order.getListOrder().size() > 0)
        {
            System.out.println("| Size \t\t Price \t\t\t Toppings \t\t|");
            System.out.println("|---------------------------------------------------------------|");
            for (Pizza p : order.getListOrder())
            {
                String builder = "| " + p.getSize() + "\t\t $" + p.getPrice() + "\t\t ";
                total += p.getPrice();
                if (p.getListToping().isEmpty())
                {
                    builder += "No topping. \t|";
                    System.out.println(builder);
                    System.out.println("|---------------------------------------------------------------|");
                } else
                {
                    int countTemp = 0;
                    total += p.getListToping().size() * priceEachTopping;
                    for (String t : p.getListToping())
                    {
                        if (countTemp == 0)
                        {
                            System.out.println(builder + t + "  each $" + priceEachTopping + "\t|");
                            countTemp++;
                        } else
                        {
                            System.out.println("|\t\t\t\t\t" + t + "  each $" + priceEachTopping + "\t|");
                        }
                    }
                    //System.out.println("|\t\t\t\t\t  total topping: $" + p.getListToping().size() + "\t|");
                    System.out.println("|---------------------------------------------------------------|");
                }
            }
            if (method == Shipment.DELIVERY)
            {
                if (total < 30)  // if the shipment is delivery type and order amount is less than 30 then $8 is charged.
                {
                    total += deliveryCharge;
                }
            }
            System.out.println("| Total \t Order:" + order.getListOrder().size() + "\t\t $" + total + "\t\t\t|");
            
           
        } else
        {
            System.out.println("| Empty pizza items in order cart.\t\t|");
        }
        System.out.println("|---------------------------------------------------------------|");
    }

    // Display of summary information of order
    public void shipmentSummary()
    {   
        if (!CheckOrderCart()) // check if the array of order is available or not
        {
            System.out.println("No pizza items in the order cart. Make your order");
        } else
        {
            System.out.println("|-----------------------------------------------|");
            System.out.println("|\t Shipment Information \t\t|");
            System.out.println("| Note: Additional " + deliveryCharge + " charge if total is less than $30 \t\t|");
            System.out.println("|-----------------------------------------------|");
            System.out.println("|Press 0, 1, 2 and for the operations|");
            System.out.println("|-----------------------------------------------|");
            System.out.println("| 0: Return to Main Menu \t\t\t\t\t|");
            System.out.println("| 1: Self Collect \t\t\t\t|");
            System.out.println("| 2: Delivery \t\t\t\t|");
            System.out.println("|-----------------------------------------------|\n");
            String shipmentMethodId= "";
            do
            {
                String name = "", address = "";
                int phone = 0;
                System.out.print("Shipment Method Type No.: ");
                // Taking input operation from the console.
                shipmentMethodId = in.nextLine();
                switch (shipmentMethodId)
                {
                    case "0": // breaking out of do while loop and return to main menu.
                        shipmentMethodId = "0"; 
                        break;
                    case "1":
                        // pickup option from the store
                        name = CheckString("Name");
                        phone = CheckNumber("Phone");
                        order.setName(name);
                        order.setPhone(phone);

                        System.out.println("\n Your order summary");
                        System.out.println("Name: " + order.getName() + " \t Phone: " + order.getPhone());
                        orderCart(Shipment.COLLECT);
                        clearOrderCart("SHIPMENT");
                        shipmentMethodId = "0"; // for exiting the currnt while loop and return to main menu.
                        System.out.println("\n Thank you for ordering.");
                        System.out.println("\n Your new order.Please");
                        break;
                    case "2": // Collection of delivery option
                        name = CheckString("Name");
                        phone = CheckNumber("Phone");
                        address = CheckString("Address");
                        order.setName(name);
                        order.setPhone(phone);
                        order.setAddress(address);
                        System.out.println("\n Your order summary");
                        System.out.println("Name: " + order.getName() + " \t Phone: " + order.getPhone() + "\t Address: " + order.getAddress());
                        orderCart(Shipment.DELIVERY);
                        clearOrderCart("SHIPMENT");
                        shipmentMethodId = "0";
                        System.out.println("\n Thank you for ordering.");
                        System.out.println("\n Your new order.Please");
                        break;
                    default:
                        System.out.println("Invaid method Id. Check shipment method type Id.\n");
                }
            } while (shipmentMethodId != "0");
        }
    }

    public boolean CheckOrderCart()
    {
        if (order.getListOrder().size() > 0)
        {
            return true;
        } else
        {
            return false;
        }
    }

    public String CheckString(String n)
    {
        String temp = "";
        do
        {
            System.out.print("\n Your " + n + ": ");
            temp = in.nextLine();
        } while (temp.isEmpty());
        return temp;
    }

    public int CheckNumber(String p)
    {
        int temp = 0;
        do
        {
            try
            {
                System.out.print("\n " + p + ": ");
                String a = in.nextLine();
                temp = Integer.parseInt(a);
            } catch (Exception e)
            {
                System.out.println("Invalid phone number.");
            }
        } while (temp <= 0);
        return temp;
    }
}
